Sample config
